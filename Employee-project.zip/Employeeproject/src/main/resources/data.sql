insert into employee(id, name, last_name) 
values(100,'shishira','Bhat');
insert into employee (id, name, last_name) 
values(101,'neelima' ,'jadhav' );
insert into employee(id, name, last_name ) 
values(102,'kashif', 'mashood');



















